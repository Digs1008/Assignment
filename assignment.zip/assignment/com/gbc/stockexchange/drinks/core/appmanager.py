'''
Created on 12-Jan-2019

@author: digvijaysingh
'''
from com.gbc.stockexchange.drinks.core.dao.entitymanager import EntityManager
from com.gbc.stockexchange.drinks.core.calculators.calculatorFactory import CalculatorFactory
from com.gbc.stockexchange.drinks.core.handlers.comandhandlers import CommandHandlerFactory



class AppManager(object):
    '''
    This class is responsible for starting the app. It would load the initial data for the whole application such as 
    stock, exchange, trade etc.
    Once all the initial data is loaded, it would listen to the user requests on console and process these. This could be further 
    extended to expose a REST api.
    The program terminates once user presses Ctrl+C or bye
     
    '''
    entityMgr = None
    


    def __init__(self, entityMgr):
        self.entityMgr = entityMgr
        self.__initialize()
        self.calcFactory = CalculatorFactory()
    
    def __initialize(self):
        
        # create stocks
        stocks = []
        stocks.append(self.entityMgr.create("Stock",**{"symbol" : "TEA","stockType": "Common","lastDividend" : 0,"fixedDividend" : 0,"parValue" :100}))
        stocks.append(self.entityMgr.create("Stock",**{"symbol" : "POP","stockType": "Common","lastDividend" : 8,"fixedDividend" : 0,"parValue" :100}))
        stocks.append(self.entityMgr.create("Stock",**{"symbol" : "ALE","stockType": "Common","lastDividend" : 23,"fixedDividend" : 0,"parValue" :60}))
        stocks.append(self.entityMgr.create("Stock",**{"symbol" : "GIN","stockType": "Preferred","lastDividend" : 8,"fixedDividend" : 2,"parValue" :100}))
        stocks.append(self.entityMgr.create("Stock",**{"symbol" : "JOE","stockType": "Common","lastDividend" : 13,"fixedDividend" : 0,"parValue" :250}))
        
        # create exchange
        self.entityMgr.create("Exchange",**{"exchangeName":"Global Beverage Corporation Exchange ","stocks":stocks})
        
        #create trade
        self.entityMgr.create("Trade",**{"stock":"ALE", "quantity":100,"price":2.5,"buySell":"B"})
        self.entityMgr.create("Trade",**{"stock":"ALE", "quantity":200,"price":2.0,"buySell":"B"})
        self.entityMgr.create("Trade",**{"stock":"GIN", "quantity":150,"price":2.0,"buySell":"B"})
        

    def start(self):
        # interactive indefinite loop which would terminate on Bye command
        handlerFactory = CommandHandlerFactory(self.entityMgr)
        while True :
            try :
                cmd = raw_input("Please enter a command with arguments")
                if cmd == "Bye":
                    break
                else :
                    tokens = cmd.split()
                    handlerFactory.getCommandHandler(tokens[0]).handle(tokens)
            except Exception,e:
                print("Current command aborted due to %s"%e)
                


def main():
    #val= "{'stock':'GIN','quantity':150,'price':2.0,'buySell':'B'}"
    entityMgr = EntityManager("memory")
    app = AppManager(entityMgr)
    app.start()
    print("Completed")
    
if __name__ == "__main__" :
    main()
    
        
    
        