'''
Created on 12-Jan-2019

@author: digvijaysingh
'''

class Exchange(object):
    
    def __init__(self, exchangeName,exchangeCode="GBC",stocks=[]):
        self.exchangeName = exchangeName
        self.exchangeCode = exchangeCode
        self.stocks = stocks
        self.key = self.exchangeCode
    
    # may have an api such as getAllStocks, getActiveStock, getStock etc