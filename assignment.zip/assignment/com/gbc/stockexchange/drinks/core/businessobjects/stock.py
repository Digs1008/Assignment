'''
Created on 12-Jan-2019

@author: digvijaysingh
'''



class Stock(object):
    
    class StockEconomics(object):
        lastDividend = None
        fixedDividend = None
        parValue = None
        
        def __init__(self, lastDividend = None,fixedDividend = None,parValue = None):
            self.lastDividend = lastDividend
            self.fixedDividend = fixedDividend
            self.parValue = parValue
        
    
    def __init__(self, symbol = None,stockType = None,lastDividend = None,fixedDividend = None,parValue = None,isActive=True):
        self.symbol = symbol
        self.stockType = stockType
        self.stockEconomics = self.StockEconomics(lastDividend,fixedDividend,parValue)
        self.isActive = isActive
        self.key = self.symbol
        
        