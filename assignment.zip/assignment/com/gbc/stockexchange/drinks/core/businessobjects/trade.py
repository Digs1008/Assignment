'''
Created on 12-Jan-2019

@author: digvijaysingh
'''
import uuid
import time

class Trade(object):
    
    def __init__(self, stock, quantity,price,buySell):
        self.id = id
        self.stock = stock
        self.quantity = quantity
        self.price = price
        self.buySell = buySell
        self.createTime = time.time() 
        self.id = uuid.uuid4() 
        self.key = stock
        