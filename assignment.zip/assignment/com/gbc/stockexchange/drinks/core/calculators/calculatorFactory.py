'''
Created on 12-Jan-2019

@author: digvijaysingh
'''
from com.gbc.stockexchange.drinks.core.util.singleton import Singleton
from functools import reduce
import time
from com.gbc.stockexchange.drinks.core.exceptions import UnsupportedFormulaException

class CalculatorFactory(object):
    '''
    This class would provide the instance of calculator as per the passed on financial attribute to be calculated
    '''
    __metaclass__ = Singleton

    def __init__(self):
        self.formulaToCalculatorMap = {
            "DY" :DividendYieldCalculator(),
            "PE":PECalculator(),
            "VWSP" :VWSPCalculator(),
            "GBCE" :GBCECalculator()
            }
    
    def getCalculator(self,formulaName):
        if formulaName not in self.formulaToCalculatorMap :
            raise UnsupportedFormulaException("%s formula is currently not supported"%formulaName)
        return self.formulaToCalculatorMap[formulaName]

        
class Calculator(object):
    
    def calculate(self,entity,attr):
        raise NotImplementedError("Please provide implementation of your formula in the calculate method")
        
class DividendYieldCalculator(Calculator):
    
    def calculate(self,stock,price):
        if stock.stockType == "Common" :
            return float(stock.stockEconomics.lastDividend)/float(price) if price!=0 else 0
        elif stock.stockType == "Preferred" :
            return (float(stock.stockEconomics.fixedDividend) * float(stock.stockEconomics.parValue))/float(price) if price!=0 else 0
    
class PECalculator(Calculator):
    
    def calculate(self,stock,price):
        ## retrieve the object from the cache and then implement the formula
        return float(price)/float(stock.stockEconomics.fixedDividend) if stock.stockEconomics.fixedDividend!=0 else 0
    
class VWSPCalculator(Calculator):
    
    def calculate(self,trades,field=None):
        # consider only those trades which are created in last 10 minutes
        curTime = time.time()
        validTrades = [trade for trade in trades if (trade.createTime - curTime)<=600]
        if not validTrades :
            return 0
        return sum([float(trade.price)*float(trade.quantity) for trade in validTrades])/sum([float(trade.quantity) for trade in validTrades])
    
class GBCECalculator(Calculator):
    
    
    def calculate(self,vswpForTrades,field=None):
        if not vswpForTrades :
            return 0
        #Check : if there is a stock which has never been traded then that would cause the
        # GBCE to be 0 as the VWSP would come as 0. Is this expected behaviour ??
        # if not then in below code we would need to exclude the zeros
        return reduce(lambda x, y: float(x)*float(y), vswpForTrades)**(1./len(vswpForTrades))
