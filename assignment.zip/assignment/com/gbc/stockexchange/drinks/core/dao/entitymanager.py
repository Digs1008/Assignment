'''
Created on 12-Jan-2019

@author: digvijaysingh
'''
from com.gbc.stockexchange.drinks.core.dao.persistentmanager import PersistentFactory
from com.gbc.stockexchange.drinks.core.exceptions import UnsupportedEntityException,UnsupportedOperationException
from com.gbc.stockexchange.drinks.core.businessobjects.trade import Trade
from com.gbc.stockexchange.drinks.core.businessobjects.stock import Stock
from com.gbc.stockexchange.drinks.core.businessobjects.exchange import Exchange
from com.gbc.stockexchange.drinks.core.util.singleton import Singleton


class EntityManager(object):
    '''
    This class has the responsibility to manage lifecycle of all the domain objects.
    '''
    __metaclass__ = Singleton


    def __init__(self, dataSource):
        self.entityToManagerMap ={
            "Trade":TradeManager(),
            "Stock":StockManager(),
            "Exchange" :ExchangeManager()
            }
        self.persistentMgr = PersistentFactory().getPersistentMgr(dataSource) ## TODO : FIX this later
    
    def fetch(self,entityName,key):
        return self.persistentMgr.fetch(entityName,key)
    
    def create(self,entityName,**kwargs):
        entityManager = self.entityToManagerMap.get(entityName);
        if not entityManager :
            raise UnsupportedEntityException("%s is not currently supported entity"%entityName)
        entity = entityManager.create(**kwargs)
        self.persistentMgr.create(entityName,entity)
        return entity
            
    
    def update(self,entityName,**kwargs):
        raise UnsupportedOperationException("Update operation would be supported in next phase for %s entity"%entityName)
    
    def delete(self,entityName,**kwargs):
        raise UnsupportedOperationException("delete operation would be supported in next phase for %s entity"%entityName)

class TradeManager(EntityManager):
    
    def __init__(self):
        pass
    
    def create(self,**kwargs):
        return Trade(**kwargs)
    
    def update(self,**kwargs):
        raise UnsupportedOperationException("Update operation would be supported in next phase for Trade entity")
    
    def delete(self,**kwargs):
        raise UnsupportedOperationException("Update operation would be supported in next phase for Trade entity")
    
class StockManager(EntityManager):
    def __init__(self):
        pass
    
    def create(self,**kwargs):
        return Stock(**kwargs)
    
    def update(self,**kwargs):
        raise UnsupportedOperationException("Update operation would be supported in next phase for Stock entity")
    
    def delete(self,**kwargs):
        raise UnsupportedOperationException("Update operation would be supported in next phase for Stock entity")
    
class ExchangeManager(EntityManager):
    def __init__(self):
        pass
    
    def create(self,**kwargs):
        return Exchange(**kwargs)
    
    def update(self,**kwargs):
        raise UnsupportedOperationException("Update operation would be supported in next phase for Exchange entity")
    
    def delete(self,**kwargs):
        raise UnsupportedOperationException("Update operation would be supported in next phase for Exchange entity")
        