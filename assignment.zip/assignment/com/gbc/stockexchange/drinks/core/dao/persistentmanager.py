'''
Created on 12-Jan-2019

@author: digvijaysingh
'''
from com.gbc.stockexchange.drinks.core.exceptions import UnsupportedDataSourceException,\
    UnsupportedEntityException,MissingDataException
from com.gbc.stockexchange.drinks.core.util.singleton import Singleton

class PersistentFactory(object):
    
    __metaclass__ = Singleton
    
    def __init__(self):
        self.dataSourceToMgrMap = {
            "memory" : InMemoryPersistentManager(),
            "file" : FilePersistentManager(),
            "db": DBPersistentManager(),
            }
    
    ## make it static method later
    def getPersistentMgr(self,dataSource):
        if dataSource not in self.dataSourceToMgrMap :
            raise UnsupportedDataSourceException("%s is not currently supported data source "%dataSource)
        return self.dataSourceToMgrMap[dataSource]
        

class BaseDaoManager(object):
    __metaclass__ = Singleton
    
    def connect(self):
        raise NotImplementedError("%s seems to be missing implementation for connect method "%self.__class__.name)

    def create(self):
        raise NotImplementedError("%s seems to be missing implementation for connect method "%self.__class__.name)
    
    def update(self):
        raise NotImplementedError("%s seems to be missing implementation for connect method "%self.__class__.name)
    
    def delete(self):
        raise NotImplementedError("%s seems to be missing implementation for connect method "%self.__class__.name)
    
    def disconnect(self):
        raise NotImplementedError("%s seems to be missing implementation for connect method "%self.__class__.name)
    

class InMemoryPersistentManager(BaseDaoManager):
    __metaclass__ = Singleton
    
    def __init__(self):
        self.memorydb = {"Trade":{},
            "Stock":{},
            "Exchange" :{}}
    
    def connect(self):
        pass
    
    def fetch(self,entityName,key):
        if entityName not in self.memorydb :
            raise UnsupportedEntityException("%s is not currently supported entity"%entityName)
        if key not in self.memorydb[entityName]:
            return None
            #raise MissingDataException("No data found for %s "%key)
        return self.memorydb[entityName][key]
    
    def create(self,entityName,entity):
        entities = self.memorydb[entityName]
        if entityName == "Trade" : ## try getting rid of this if possible or find an alternate way of saving data
            trades = entities.get(entity.key,[])
            trades.append(entity)
            entities[entity.key] = trades
        else :
            entities[entity.key] = entity
    
    def update(self):
        pass
    
    def delete(self):
        pass
    
    def disconnect(self):
        pass

class FilePersistentManager(BaseDaoManager):
    
    def connect(self):
        pass
    
    def create(self):
        pass
    
    def update(self):
        pass
    
    def delete(self):
        pass
    
    def disconnect(self):
        pass
    
class DBPersistentManager(BaseDaoManager):
    
    def connect(self):
        pass
    
    def create(self):
        pass
    
    def update(self):
        pass
    
    def delete(self):
        pass
    
    def disconnect(self):
        pass
    
    