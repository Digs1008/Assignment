'''
Created on 13-Jan-2019

@author: digvijaysingh
'''

class UnsupportedEntityException(Exception):
    pass

class UnsupportedOperationException(Exception):
    pass

class UnsupportedDataSourceException(Exception):
    pass

class MissingDataException(Exception):
    pass

class UnsupportedFormulaException(Exception):
    pass

class UnsupportedCommandException(Exception):
    pass
        