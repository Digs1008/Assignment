'''
Created on 14-Jan-2019

@author: digvijaysingh
'''
from com.gbc.stockexchange.drinks.core.calculators.calculatorFactory import CalculatorFactory
from com.gbc.stockexchange.drinks.core.util.singleton import Singleton
import logging
from com.gbc.stockexchange.drinks.core.exceptions import MissingDataException,\
    UnsupportedCommandException


class CommandHandlerFactory(object):
    
    __metaclass__ = Singleton
    
    def __init__(self,entityMgr):
        self.commandToHandlerMap = {
            "Create" :CreateCommandHandler(entityMgr),
            "PE":PECommandHandler(entityMgr),
            "DY" :DYCommandHandler(entityMgr),
            "VWSP" :VWSPCommandHandler(entityMgr),
            "GBCE" :GBCECommandHandler(entityMgr)
            }
    
    def getCommandHandler(self,cmd):
        if cmd not in self.commandToHandlerMap:
            raise UnsupportedCommandException("%s is not currently supported command"%cmd)
        return self.commandToHandlerMap[cmd]

class Handler(object):
    
    def __init__(self,entityMgr):
        self.entityMgr = entityMgr
        self.calcFactory = CalculatorFactory()

    def handle(self):
        raise NotImplementedError("Implementation is missing for current command") 

class CreateCommandHandler(Handler):
    
    def handle(self,tokens):
        if len(tokens)!=3 :
            print("Invalid command : usage is create Stock|Trade json_dict_data")
            return
        import json
        json_acceptable_string = tokens[2].replace("'", "\"")
        args = json.loads(json_acceptable_string)
        entity = self.entityMgr.create(tokens[1],**args)
        logging.info("%s got created with key as %s"%(tokens[1],entity.key))
        print("%s got created with key as %s"%(tokens[1],entity.key))
        return entity

class PECommandHandler(Handler):
    
    def handle(self,tokens):
        if len(tokens)!=3 :
            print("Invalid command : usage is PE stocksymbol price")
            return 0
        stk = self.entityMgr.fetch("Stock",tokens[1])
        if not stk :
            logging.error("Stock information not found for %s"%tokens[1])
            raise MissingDataException("Stock information not found for %s"%tokens[1])
        calculator = self.calcFactory.getCalculator(tokens[0])
        peVal = calculator.calculate(stk,float(tokens[2]))
        print("P/E ratio is {0:.3f}".format(peVal))
        return peVal
    
class DYCommandHandler(Handler):
    
    def handle(self,tokens):
        if len(tokens)!=3 :
            print("Invalid command : usage is DY stocksymbol price")
            return 0
        stk = self.entityMgr.fetch("Stock",tokens[1])
        if not stk :
            logging.error("Stock information not found for %s"%tokens[1])
            raise MissingDataException("Stock information not found for %s"%tokens[1])
        calculator = self.calcFactory.getCalculator(tokens[0])
        peVal = calculator.calculate(stk,float(tokens[2]))
        print("Dividend yield is {0:.3f}".format(peVal))
        return peVal

class VWSPCommandHandler(Handler):
    
    def handle(self,tokens):
        if len(tokens)!=2 :
            print("Invalid command : usage is VWSP stocksymbol")
            return 0
        trades = self.entityMgr.fetch("Trade",tokens[1])
        if not trades :
            logging.warn("No trades found for stock %s"%tokens[1])
            print("No trades found for stock %s hence VWSP is zero"%tokens[1])
            return 0
        calculator = self.calcFactory.getCalculator(tokens[0])
        vwspVal = calculator.calculate(trades,None)
        print("VWSP is {0:.3f}".format(vwspVal))
        return vwspVal
    
class GBCECommandHandler(Handler):
    
    def handle(self,tokens):
        exch  = "GBC"
        if len(tokens)==2 :
            exch = tokens[1]
        elif len(tokens)!=1 :
            print("Invalid command : usage is GBCE exchange")
            return 0
        vswpCalc = self.calcFactory.getCalculator("VWSP")
        exch = self.entityMgr.fetch("Exchange",exch)
        if not exch :
            logging.warn("No exchange info for exch %s"%exch)
            print("No information found for exchange %s hence GBCE is zero"%tokens[1])
            return 0
        vswpForTrades = [vswpCalc.calculate(self.entityMgr.fetch("Trade",stock.symbol) or [],None) for stock in exch.stocks]
        gbceCalc = self.calcFactory.getCalculator("GBCE")
        gbceVal = gbceCalc.calculate(vswpForTrades,None)
        print("GBCE is {0:.3f}".format(gbceVal))
        return gbceVal
        
        