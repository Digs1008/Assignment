'''
Created on 13-Jan-2019

@author: digvijaysingh
'''

class Singleton(type):
    '''
    A class that would be used as decorator for making classes as singleton
    '''
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

