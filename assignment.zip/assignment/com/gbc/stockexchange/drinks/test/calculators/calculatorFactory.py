'''
Created on 13-Jan-2019

@author: digvijaysingh
'''
import unittest
from datetime import datetime, timedelta
from com.gbc.stockexchange.drinks.core.calculators.calculatorFactory import CalculatorFactory,DividendYieldCalculator,GBCECalculator,VWSPCalculator,PECalculator
from com.gbc.stockexchange.drinks.core.exceptions import UnsupportedFormulaException
from com.gbc.stockexchange.drinks.core.businessobjects.stock import Stock
from com.gbc.stockexchange.drinks.core.businessobjects.trade import Trade


class TestCalculatorFactory(unittest.TestCase):
    
    def testGetCalculator_supportedCalc(self):
        factory = CalculatorFactory()
        self.assertEquals(type(factory.getCalculator("DY")),DividendYieldCalculator)
        self.assertEquals(type(factory.getCalculator("PE")),PECalculator)
        self.assertEquals(type(factory.getCalculator("VWSP")),VWSPCalculator)
        self.assertEquals(type(factory.getCalculator("GBCE")),GBCECalculator)
        
    
    def testGetCalculator_UnsupportedCalc(self):
        factory = CalculatorFactory()
        with self.assertRaises(UnsupportedFormulaException):
            factory.getCalculator("Random")

class TestDividendYieldCalculator(unittest.TestCase):
    
    def testCalculate_common_priceNonzero(self):
        stock = Stock(symbol = "TEST",stockType = "Common",lastDividend = 3)
        divCalc = DividendYieldCalculator()
        self.assertEquals(divCalc.calculate(stock, 3),1)
    
    def testCalculate_common_priceZero(self):
        stock = Stock(symbol = "TEST",stockType = "Common",lastDividend = 3)
        divCalc = DividendYieldCalculator()
        self.assertEquals(divCalc.calculate(stock, 0),0)
    
    def testCalculate_preferred_priceNonzero(self):
        stock = Stock(symbol = "TEST",stockType = "Preferred",fixedDividend = 2,parValue = 2)
        divCalc = DividendYieldCalculator()
        self.assertEquals(divCalc.calculate(stock, 1),4)
    
    def testCalculate_preferred_priceZero(self):
        stock = Stock(symbol = "TEST",stockType = "Preferred",fixedDividend = 2,parValue = 2)
        divCalc = DividendYieldCalculator()
        self.assertEquals(divCalc.calculate(stock, 0),0)

class TestPECalculator(unittest.TestCase):
    
    def testCalculate_price_and_fixedDividend_Nonzero(self):
        stock = Stock(symbol = "TEST",stockType = "Common",lastDividend = 3,fixedDividend = 2,parValue = 2)
        peCalc = PECalculator()
        self.assertEquals(peCalc.calculate(stock, 3),1.5)
    
    def testCalculate_common_price_and_fixedDividend_Zero(self):
        stock = Stock(symbol = "TEST",stockType = "Common",lastDividend = 3,fixedDividend = 0)
        peCalc = PECalculator()
        self.assertEquals(peCalc.calculate(stock, 0),0)
    
    def testCalculate_common_only_fixedDividend_Zero(self):
        stock = Stock(symbol = "TEST",stockType = "Common",lastDividend = 3,fixedDividend = 0)
        peCalc = PECalculator()
        self.assertEquals(peCalc.calculate(stock, 3),0)

class TestVWSPCalculator(unittest.TestCase):
    
    def testCalculate_NoTrades(self):
        vwspCalc = VWSPCalculator()
        self.assertEquals(vwspCalc.calculate([], 3),0)
    
    def testCalculate_AllTrades_10mins_eligible(self):
        vwspCalc = VWSPCalculator()
        trade1 = Trade("TEST", 100,1.5,'B')
        trade2 = Trade("TEST", 200,2.5,'B')
        trade3 = Trade("TEST", 300,2.0,'B')
        trades =[]
        trades.append(trade1)
        trades.append(trade2)
        trades.append(trade3)
        self.assertEquals(float("{0:.3f}".format(vwspCalc.calculate(trades))),2.083)
    
    def testCalculate_SomeTrades_10mins_eligible(self):
        vwspCalc = VWSPCalculator()
        trade1 = Trade("TEST", 100,1.5,'B')
        trade2 = Trade("TEST", 200,2.5,'B')
        trade3 = Trade("TEST", 300,2.0,'B')
        newTime = datetime.now() + timedelta(hours=-1)
        trade3.createTime = (newTime - datetime(1970,1,1)).total_seconds()
        trades =[]
        trades.append(trade1)
        trades.append(trade2)
        trades.append(trade3)
        self.assertEquals(float("{0:.3f}".format(vwspCalc.calculate(trades))),2.167)
    
    def testCalculate_NoTrades_10mins_eligible(self):
        vwspCalc = VWSPCalculator()
        trade1 = Trade("TEST", 100,1.5,'B')
        trade2 = Trade("TEST", 200,2.5,'B')
        trade3 = Trade("TEST", 300,2.0,'B')
        newTime = datetime.now() + timedelta(hours=-1)
        trade3.createTime = (newTime - datetime(1970,1,1)).total_seconds()
        trade2.createTime = (newTime - datetime(1970,1,1)).total_seconds()
        trade1.createTime = (newTime - datetime(1970,1,1)).total_seconds()
        trades =[]
        trades.append(trade1)
        trades.append(trade2)
        trades.append(trade3)
        self.assertEquals(float("{0:.3f}".format(vwspCalc.calculate(trades))),0.000)

class TestGBCECalculator(unittest.TestCase):
    
    def testCalculate_NoVWSP(self):
        gbceCalc = GBCECalculator()
        self.assertEquals(gbceCalc.calculate([], 3),0)
    
    def testCalculate_VWSP_present(self):
        gbceCalc = GBCECalculator()
        vwsp =[2.2,4.2,9.3]
        self.assertEquals(float("{0:.3f}".format(gbceCalc.calculate(vwsp))),4.413)
    
    
