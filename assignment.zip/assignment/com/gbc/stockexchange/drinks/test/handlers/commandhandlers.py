'''
Created on 14-Jan-2019

@author: digvijaysingh
'''
import unittest
import mock
from mock import Mock
from com.gbc.stockexchange.drinks.core.exceptions import UnsupportedCommandException
from com.gbc.stockexchange.drinks.core.businessobjects.stock import Stock
from com.gbc.stockexchange.drinks.core.businessobjects.trade import Trade
from com.gbc.stockexchange.drinks.core.handlers.comandhandlers import CreateCommandHandler,\
    PECommandHandler, DYCommandHandler, VWSPCommandHandler, GBCECommandHandler,\
    CommandHandlerFactory
from com.gbc.stockexchange.drinks.core.dao.entitymanager import EntityManager


class TestCommandHandlerFactory(unittest.TestCase):
    
    def testGetCommandHandler_supportedHandlers(self):
        entityMgr = Mock()
        factory = CommandHandlerFactory(entityMgr)
        self.assertEquals(type(factory.getCommandHandler("Create")),CreateCommandHandler)
        self.assertEquals(type(factory.getCommandHandler("DY")),DYCommandHandler)
        self.assertEquals(type(factory.getCommandHandler("PE")),PECommandHandler)
        self.assertEquals(type(factory.getCommandHandler("VWSP")),VWSPCommandHandler)
        self.assertEquals(type(factory.getCommandHandler("GBCE")),GBCECommandHandler)
        
    
    def testGetCommandHandler_UnsupportedCalc(self):
        entityMgr = Mock()
        factory = CommandHandlerFactory(entityMgr)
        with self.assertRaises(UnsupportedCommandException):
            factory.getCommandHandler("Random")
            
class TestCreateCommandHandler(unittest.TestCase):
    
    def testHandle_create_trade(self):
        trade = Trade("GIN",150,2.0,'B')
        entityMgr = EntityManager("memory")
        handler = CreateCommandHandler(entityMgr)
        with mock.patch('com.gbc.stockexchange.drinks.core.dao.entitymanager.EntityManager.create', return_value=trade):
            retVal = handler.handle(["Create","Trade","{'stock':'GIN','quantity':150,'price':2.0,'buySell':'B'}"])
            self.assertEquals(retVal.key,trade.key) 
    
    def testHandle_create_stock(self):
        stock = Stock("GIN","Preferred")
        entityMgr = EntityManager("memory")
        handler = CreateCommandHandler(entityMgr)
        with mock.patch('com.gbc.stockexchange.drinks.core.dao.entitymanager.EntityManager.create', return_value=stock):
            retVal = handler.handle(["Create","Stock","{'stock':'GIN','stockType':'Preferred'}"])
            self.assertEquals(retVal.key,stock.key) 
            

class TestPECommandHandler(unittest.TestCase):
    
    def testHandle_pe_preferred_stock(self):
        stock = Stock("GIN","Preferred",8,2,100)
        entityMgr = EntityManager("memory")
        handler = PECommandHandler(entityMgr)
        with mock.patch('com.gbc.stockexchange.drinks.core.dao.entitymanager.EntityManager.fetch', return_value=stock):
            retVal = handler.handle(["PE","GIN",2])
            self.assertEquals(retVal,1.0) 
    
    def testHandle_pe_common_stock(self):
        stock = Stock("TEA","Common",8,2,100)
        entityMgr = EntityManager("memory")
        handler = PECommandHandler(entityMgr)
        with mock.patch('com.gbc.stockexchange.drinks.core.dao.entitymanager.EntityManager.fetch', return_value=stock):
            retVal = handler.handle(["PE","TEA",2])
            self.assertEquals(retVal,1.0) 
            
            
class TestDYCommandHandler(unittest.TestCase):
    
    def testHandle_DY_preferred_stock(self):
        stock = Stock("GIN","Preferred",8,2,100)
        entityMgr = EntityManager("memory")
        handler = DYCommandHandler(entityMgr)
        with mock.patch('com.gbc.stockexchange.drinks.core.dao.entitymanager.EntityManager.fetch', return_value=stock):
            retVal = handler.handle(["DY","GIN",2])
            self.assertEquals(retVal,100.0) 
    
    def testHandle_DY_common_stock(self):
        stock = Stock("TEA","Common",8,2,100)
        entityMgr = EntityManager("memory")
        handler = DYCommandHandler(entityMgr)
        with mock.patch('com.gbc.stockexchange.drinks.core.dao.entitymanager.EntityManager.fetch', return_value=stock):
            retVal = handler.handle(["DY","TEA",2])
            self.assertEquals(retVal,4.0) 
            

class TestVWSPCommandHandler(unittest.TestCase):
    
    def testHandle_VWSP_singleTrade(self):
        trade = Trade("GIN",150,2.0,'B')
        entityMgr = EntityManager("memory")
        handler = VWSPCommandHandler(entityMgr)
        with mock.patch('com.gbc.stockexchange.drinks.core.dao.entitymanager.EntityManager.fetch', return_value=[trade]):
            retVal = handler.handle(["VWSP","GIN"])
            self.assertEquals(retVal,2.0) 
    
    def testHandle_VWSP_multipleTrade(self):
        trade1 = Trade("GIN",150,2.0,'B')
        trade2 = Trade("GIN",250,3.0,'B')
        entityMgr = EntityManager("memory")
        handler = VWSPCommandHandler(entityMgr)
        with mock.patch('com.gbc.stockexchange.drinks.core.dao.entitymanager.EntityManager.fetch', return_value=[trade1,trade2]):
            retVal = handler.handle(["VWSP","GIN"])
            self.assertEquals(retVal,2.625) 
            
            