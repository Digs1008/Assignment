'''
Created on 14-Jan-2019

@author: digvijaysingh
'''
import unittest
from _pyio import __metaclass__
from com.gbc.stockexchange.drinks.core.util.singleton import Singleton

class Test(object):
    __metaclass__ = Singleton

class Test2(object):
    __metaclass__ = Singleton


class TestSingleton(unittest.TestCase):
    
    def test_creation_multiple(self):
        t1 = Test()
        t2 = Test()
        t3 = Test2()
        t4 = Test2()
        self.assertEquals(t1, t2)
        self.assertEquals(t3, t4)
        self.assertNotEquals(t1, t3)
        self.assertEquals(len(Singleton._instances),2)
        
